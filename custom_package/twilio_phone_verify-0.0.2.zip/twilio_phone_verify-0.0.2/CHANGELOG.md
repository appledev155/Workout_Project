## [0.0.2] - 2020-09-10

* Readme edits.

## [0.0.1] - 2020-09-10

* Initial development release.
