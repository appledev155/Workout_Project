//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<nexmo_verify/NexmoVerifyPlugin.h>)
#import <nexmo_verify/NexmoVerifyPlugin.h>
#else
@import nexmo_verify;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [NexmoVerifyPlugin registerWithRegistrar:[registry registrarForPlugin:@"NexmoVerifyPlugin"]];
}

@end
