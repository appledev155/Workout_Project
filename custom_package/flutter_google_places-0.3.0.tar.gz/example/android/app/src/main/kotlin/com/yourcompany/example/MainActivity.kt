package com.yourcompany.example;

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}